package com.uer.healthcure;

public class DbParameter {
    String url="http://mahavidyalay.in/Academic2021/HealthCareManagement/";

    public String getHostpath(){
        return this.url;

    }
}
